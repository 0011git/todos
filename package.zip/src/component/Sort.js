import React, { useState } from 'react'
import store from '../state/store'
import List from './component/List';


const Sort = ({setType}) => {
  const [type, setType] = useState('all');

  // sortData 안쓰고
  // if(all){  //전체
  //   li에서 display:none 해주는 클래스 삭제
  // }else if(progress){ //진행중
  //   display:none 클래스 삭제
  //   status === true(체크박스 클릭됨) 인 li에 display:none 클래스 추가
  // }else{	//완료
  //   display:none 클래스 삭제
  //   status === false(클릭x) 인 li에 display:none 클래스 추가
  // }

  //--------------------------------------------------
  // let {data,sortData,sortCtrl} = store();  
  // let [type,setType] = useState('All');

  // useEffect(()=>{
  //   sortCtrl({type});
  // },[data, type])
  //--------------------------------------------------

  return (
    <div className='sort'>
        <h4>할 일 : </h4>
        <ul>
          <li>
            <label htmlFor='all'>
              <input onClick={(e) => {setType(e.target.id);} } type='radio' name='sort' id='all' defaultChecked/>전체
            </label>
          </li>
          <li>
            <label htmlFor='progress'>
              <input onClick={(e) => {setType(e.target.id);} } type='radio' name='sort' id='progress'/>진행중
            </label>
          </li>
          <li>
            <label htmlFor='complete'>
              <input onClick={(e) => {setType(e.target.id);} } type='radio' name='sort' id='complete'/>완료
            </label>
          </li>
          
        
          {/* -------------------------------------------------- 
          <button onClick={()=>setType('All')}>All</button>
          <button onClick={()=>setType('Active')}>Active</button>
          <button onClick={()=>setType('Completed')}>Completed</button> 
          ----------------------------------------------------- */}

        </ul>
        <hr />
        <List type={type} />
    </div>
  )
}

export default Sort